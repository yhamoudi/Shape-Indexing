#!/bin/bash

python3 src/similarity.py $1 $2
