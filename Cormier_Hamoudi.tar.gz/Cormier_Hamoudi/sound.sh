#!/bin/bash

python3 src/sound.py $1
