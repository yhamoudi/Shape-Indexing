#!/bin/bash

python3 src/sound_game.py
